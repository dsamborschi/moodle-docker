<?php
$string['pluginname'] = 'Grade Report Submission';
$string['externalurl'] = 'External URL';
$string['externalurldesc'] = 'URL to send the approved grade report to.';
