<?php
function local_gradereport_submit_report_approved($reportid) {
    global $DB;

    $report = $DB->get_record('gradereport_submissions', ['id' => $reportid, 'approved' => 1], '*', MUST_EXIST);
    $adminconfig = get_config('local_gradereport_submit');
    $externalurl = $adminconfig->externalurl;

    // Use CURL to send report data to the external URL.
    $curl = new curl();
    $options = [
        'CURLOPT_RETURNTRANSFER' => true,
        'CURLOPT_HTTPHEADER' => ['Content-Type: application/json'],
    ];

    $postdata = json_encode([
        'courseid' => $report->courseid,
        'userid' => $report->userid,
        'reportdata' => $report->reportdata
    ]);

    $response = $curl->post($externalurl, $postdata, $options);
    return $response;
}
