<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_gradereport_submit', get_string('pluginname', 'local_gradereport_submit'));

    $settings->add(new admin_setting_configtext(
        'local_gradereport_submit/externalurl',
        get_string('externalurl', 'local_gradereport_submit'),
        get_string('externalurldesc', 'local_gradereport_submit'),
        '',
        PARAM_URL
    ));

    $ADMIN->add('localplugins', $settings);
}
