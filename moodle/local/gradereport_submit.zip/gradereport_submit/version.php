<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2023100600;  // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2023042400;  // Requires Moodle 4.3 version.
$plugin->component = 'local_gradereport_submit';  // Full name of the plugin.
