namespace local_gradereport_submit;

defined('MOODLE_INTERNAL') || die();

class report {
    public static function submit_report($courseid, $userid, $reportdata) {
        global $DB;
        $record = new \stdClass();
        $record->courseid = $courseid;
        $record->userid = $userid;
        $record->reportdata = $reportdata;
        $record->approved = 0; // Pending approval.
        $DB->insert_record('gradereport_submissions', $record);
    }

    public static function approve_report($reportid) {
        global $DB;
        $DB->set_field('gradereport_submissions', 'approved', 1, ['id' => $reportid]);
    }
}
